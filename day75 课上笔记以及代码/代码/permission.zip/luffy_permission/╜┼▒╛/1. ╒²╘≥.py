import re

ret = re.match(r'^/login/$','/login/xxxx')
print(ret)